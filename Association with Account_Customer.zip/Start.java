import java.lang.*;


public class Start
{
	public static void main(String[] args)
	{
		Account a1 = new Account(101, 1500);
		Account a2 = new Account(102, 1600);
		//Account a3 = new Account(103, 1700);
		//Account a4 = new Account(104, 1900);
		//Account a5 = new Account(105, 1800);
		
		Customer c1 = new Customer("Bruce", 501, a1);
		Customer c2 = new Customer("Lee", 502, a2);
		
		c1.display();
		
		c1.performDeposit(500);
		
		c1.display();
		
		c1.performTransfer(c2, 500);
		c1.display();
		c2.display();
		
		
	}
}
