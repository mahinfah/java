import java.lang.*;
public class Customer
{
	private String cusName;
	private int cusID;
	private Account acc;// 1 to 1
	
	public Customer()
	{
		
	}
	public Customer(String cusName, int cusID, Account acc)
	{
		this.cusName=cusName;
		this.cusID = cusID;
		this.acc = acc;
	}
	public void setName(String cusName)
	{
		this.cusName = cusName;
	}
	public void setID(int cusID)
	{
		this.cusID = cusID;
	}
	public void setAcc(Account acc)
	{
		this.acc = acc;
	}
	public String getName()
	{
		return cusName;
	}
	public int getID()
	{
		return cusID;
	}
	public Account getAcc()
	{
		return acc;
	}
	public void display()
	{
		System.out.println("Customer Name: "+cusName);
		System.out.println("Customer ID: "+cusID);
		System.out.println("Customer Account Details: ");
		acc.display();
	}
	public void performDeposit(double amount)
	{
		acc.deposit(amount);
	}
	public void performTransfer(Customer c, double amount)
	{
		acc.transfer(c.acc, amount);
	}
	
	
}