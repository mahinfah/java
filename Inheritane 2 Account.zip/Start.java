import java.lang.*;


public class Start
{
	public static void main(String[] args)
	{
		SavingsAccount sa1 = new SavingsAccount();
		sa1.setAno(101);
		sa1.setBalance(1500);
		sa1.setTenureYear(2);
		
		sa1.deposit(500);
		sa1.withdraw(200);
		
		sa1.display();
		
		CurrentAccount ca1 = new CurrentAccount(201, 2500, 10);
		ca1.setBalance(3500);
		ca1.deposit(400);
		ca1.withdraw(300);
		ca1.setDailyNumTran(5);
		
		ca1.display();
	}
}
