import java.lang.*;
public class Start
{
	public static void main(String[] args)
	{
		Calculator c1 = new Calculator();
		c1.setModel("MS-100");
		c1.setPrice(400);
		
		Calculator c2 = new Calculator("FX-991", 1200);
		
		Student s1 = new Student();
		s1.setID(101);
		s1.setCalc(c1);
		
		s1.performAddition(3, 2);
		
		Student s2 = new Student(102, c2);
		
		s2.performSubtraction(5, 3);
		
		s1.display();
		s2.display();
	}
}