import java.lang.*;
public class Student
{
	private int id;
	private Calculator calc;
	
	public Student()
	{
		System.out.println("Empty Student.");
	}
	public Student(int id, Calculator calc)
	{
		System.out.println("Param Student.");
		this.id = id;
		this.calc = calc;
	}
	public void setID(int id)
	{
		this.id = id;
	}
	public void setCalc(Calculator calc)
	{
		this.calc = calc;
	}
	public int getID()
	{
		return id;
	}
	public Calculator getCalc()
	{
		return calc;
	}
	public void display()
	{
		System.out.println("ID: "+id);
		//System.out.println("Calc: "+calc);
		calc.display();
		//c1.display();
		//c2.display();
	}
	public void performAddition(int a, int b)
	{
		calc.addition(a, b);
		//c1.addition(3,2);
	}
	public void performSubtraction(int a, int b)
	{
		calc.subtraction(a, b);
		//c2.subtraction(5, 3);
		
	}
}