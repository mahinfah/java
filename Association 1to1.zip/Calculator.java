import java.lang.*;
public class Calculator
{
	private String model;
	private double price;
	
	public Calculator()
	{
		System.out.println("Empty Calc.");
	}
	public Calculator(String model, double price)
	{
		System.out.println("Param. Calc.");
		this.model = model;//setModel(model)
		this.price = price;//setPrice(price)
	}
	public void setModel(String model)
	{
		this.model = model;
	}
	public void setPrice(double price)
	{
		if(price>0)
		{
			this.price = price;
		}
		else
		{
			System.out.println("Invalid Amount!");
		}
	}
	public String getModel()
	{
		return model;
	}
	public double getPrice()
	{
		return price;
	}
	public void display()
	{
		System.out.println("Model: "+model);
		System.out.println("Price: "+price);
	}
	public void addition(int a, int b)
	{
		System.out.println(a+b);
	}
	public void subtraction(int a, int b)
	{
		System.out.println(a-b);
	}
	public void multiplication(int a, int b)
	{
		System.out.println(a*b);
	}
	public void division(int a, int b)
	{
		if(b!=0)
		{
			System.out.println(a/b);
		}
		else
		{
			System.out.println(a);
		}
		
	}
	
}