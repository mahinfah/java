import java.lang.*;
public class fcb extends rm{
	
	private int  salary;
	public fcb(){
		
	}
	
	
	
	//}
	//public void setname(){
	//super(name)  ;}
	 //public void setdigit(){
	 //super(name);}
		 
	 
	
	public void setsalary(int salary){
		
		this.salary=salary;
	}
	//public int getsalary(){
	//	System.out.println("salary :__________"+salary);
	//super.display();
	//return salary;
	//}
	public void display(){
		
		super.display();
		System.out.println("display salary :"+salary);
	
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}