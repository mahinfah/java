import java.lang.*;
public class rm{
	
	private  String name ;
	private int  digit;
	
	public rm(){
		System.out.println("em constructor");
		
	}
	public void setname(String name){
	this.name = name;
	}
	 public void setdigit(int digit){
	 this.digit=digit;
	 
	 }
		 
	 
	public void  display(){
		System.out.println("name   :"+name);
		System.out.println("digit  :"+digit);
		System.out.println("fy-----");
		
		
	}

	
	
	
}