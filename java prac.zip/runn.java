import java.lang.*;
public class runn{
	 public static void main(String []args){
		 
		fcb s1= new fcb();
s1.setname("anss");
s1.setdigit(23);		
		 
		 s1.setsalary(3);
		 s1.display();
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 }
	 
 }