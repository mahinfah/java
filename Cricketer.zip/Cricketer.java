import java.lang.*;

public class Cricketer extends Player{
	
	private int matchPlayed;
	private int totalRun;
	private int totalWicket;
	public Cricketer(){
		System.out.println("em");
		
	}
	
	public Cricketer(int id , String name , double salary,int matchPlayed,int totalRun,int totalWicket)
	{
		
	super(id,name,salary);
	setMatchPlayed(matchPlayed);
	setTotalRun(totalRun);	
	setTotalWicket(totalWicket);	
	}

 public void setMatchPlayed(int matchPlayed){
    this.matchPlayed=matchPlayed;
 }	
		public void setTotalRun(int totalRun){
			this.totalRun=totalRun;
		}
		    
	public void setTotalWicket(int totalWicket){
		
		this.totalWicket=totalWicket;
	}
	
	public int getMatchPlayed(){
		return matchPlayed;
	}
	
	public int getTotalRun(){
		
	return totalRun;}
	
	
	
	public int getTotalWicket(){
		return totalWicket;
	}
	 double avgRun(){
		 
		double avgRun=totalRun/matchPlayed;
		return avgRun;
	 }
	  
	  double avgWicket(){
		   double avgWicket=(matchPlayed/totalWicket);
	    return avgWicket;
	  }
	double annualSalary(){
		double annualSalary =getSalary()*12;
		return annualSalary;
		
	}
	
	public void showInfo(){
		super.showInfo();
		System.out.println("matchPlayed  :"+matchPlayed);
		System.out.println("totalRun     :"+totalRun);
		System.out.println("totalWicket  :"+totalWicket);
		
		
	}
	

	
	
}