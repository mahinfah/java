import java.lang.*;

public class Start2
{
	public static void main(String[] args)
	{
	Cricketer s1 = new Cricketer(233243,"sakib al hasan",40000,12,500,3);
	
	s1.showInfo();
	System.out.println("avg run       :"+s1.avgRun());
	System.out.println("yearly salary :"+s1.annualSalary());
	System.out.println("avg wicket    :"+s1.avgWicket());
	}
		

}